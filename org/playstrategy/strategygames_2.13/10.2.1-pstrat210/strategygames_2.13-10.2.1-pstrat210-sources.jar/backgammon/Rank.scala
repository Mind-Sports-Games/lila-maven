package strategygames.backgammon

case class Rank private (val index: Int) extends AnyVal with Ordered[Rank] {

  @inline def -(that: Rank): Int           = index - that.index
  @inline override def compare(that: Rank) = this - that

  def offset(delta: Int): Option[Rank] =
    if (-Rank.all.size < delta && delta < Rank.all.size) Rank(index + delta)
    else None

  @inline def char: Char = if (index < File.all.size) (49 + index).toChar else 48.toChar // 0
  override def toString  = (index + 1).toString

}

object Rank {

  def apply(index: Int): Option[Rank] =
    if (0 <= index && index < all.size) Some(new Rank(index))
    else None

  @inline def of(pos: Pos): Rank = new Rank(pos.index / File.all.size)

  def fromChar(ch: Char): Option[Rank] =
    apply(if (ch.toInt == 48) File.all.size else ch.toInt - 49)

  val First  = new Rank(0)
  val Second = new Rank(1)

  val all                     = List(First, Second)
  val allReversed: List[Rank] = all.reverse

}
