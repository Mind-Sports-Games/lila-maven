package strategygames

final class Hash(size: Int) {
  def apply(lib: GameLogic, situation: Situation): PositionHash = {
    val l = Hash.get(lib, situation, Hash.polyglotTable(lib))
    if (size <= 8) {
      Array.tabulate(size)(i => (l >>> ((7 - i) * 8)).toByte)
    } else {
      val m = Hash.get(lib, situation, Hash.randomTable(lib))
      Array.tabulate(size)(i =>
        if (i < 8) (l >>> ((7 - i) * 8)).toByte
        else (m >>> ((15 - i) * 8)).toByte
      )
    }
  }
}

object Hash {
  val size = 3

  sealed abstract class ZobristConstants {
    def hexToLong(s: String): Long
    val p1TurnMask: Long
    val actorMasks: Array[Long]
  }

  final case class ChessZobristConstants(zc: chess.Hash.ZobristConstants) extends ZobristConstants {
    def hexToLong(s: String): Long = zc.hexToLong(s)
    val p1TurnMask: Long           = zc.p1TurnMask
    val actorMasks: Array[Long]    = zc.actorMasks
  }

  final case class DraughtsZobristConstants(zc: draughts.Hash.ZobristConstants) extends ZobristConstants {
    def hexToLong(s: String): Long = zc.hexToLong(s)
    val p1TurnMask: Long           = zc.p1TurnMask
    val actorMasks: Array[Long]    = zc.actorMasks
  }

  final case class FairySFZobristConstants(zc: fairysf.Hash.ZobristConstants) extends ZobristConstants {
    def hexToLong(s: String): Long = zc.hexToLong(s)
    val p1TurnMask: Long           = zc.p1TurnMask
    val actorMasks: Array[Long]    = zc.actorMasks
  }

  final case class SamuraiZobristConstants(zc: samurai.Hash.ZobristConstants) extends ZobristConstants {
    def hexToLong(s: String): Long = zc.hexToLong(s)
    val p1TurnMask: Long           = zc.p1TurnMask
    val actorMasks: Array[Long]    = zc.actorMasks
  }

  final case class TogyzkumalakZobristConstants(zc: togyzkumalak.Hash.ZobristConstants)
      extends ZobristConstants {
    def hexToLong(s: String): Long = zc.hexToLong(s)
    val p1TurnMask: Long           = zc.p1TurnMask
    val actorMasks: Array[Long]    = zc.actorMasks
  }

  final case class GoZobristConstants(zc: go.Hash.ZobristConstants) extends ZobristConstants {
    def hexToLong(s: String): Long = zc.hexToLong(s)
    val p1TurnMask: Long           = zc.p1TurnMask
    val actorMasks: Array[Long]    = zc.actorMasks
  }

  final case class BackgammonZobristConstants(zc: backgammon.Hash.ZobristConstants) extends ZobristConstants {
    def hexToLong(s: String): Long = zc.hexToLong(s)
    val p1TurnMask: Long           = zc.p1TurnMask
    val actorMasks: Array[Long]    = zc.actorMasks
  }

  final case class AbaloneZobristConstants(zc: abalone.Hash.ZobristConstants) extends ZobristConstants {
    def hexToLong(s: String): Long = zc.hexToLong(s)
    val p1TurnMask: Long           = zc.p1TurnMask
    val actorMasks: Array[Long]    = zc.actorMasks
  }

  final case class DameoZobristConstants(zc: dameo.Hash.ZobristConstants) extends ZobristConstants {
    def hexToLong(s: String): Long = zc.hexToLong(s)
    val p1TurnMask: Long           = zc.p1TurnMask
    val actorMasks: Array[Long]    = zc.actorMasks
  }

  final case class EntropyZobristConstants(zc: entropy.Hash.ZobristConstants) extends ZobristConstants {
    def hexToLong(s: String): Long = zc.hexToLong(s)
    val p1TurnMask: Long           = zc.p1TurnMask
    val actorMasks: Array[Long]    = zc.actorMasks
  }

  final private class Tables(start: Int) {
    lazy val draughtsTable: ZobristConstants     = DraughtsZobristConstants(
      new draughts.Hash.ZobristConstants(start)
    )
    lazy val chessTable: ZobristConstants        = ChessZobristConstants(new chess.Hash.ZobristConstants(start))
    lazy val fairysfTable: ZobristConstants      = FairySFZobristConstants(
      new fairysf.Hash.ZobristConstants(start)
    )
    lazy val samuraiTable: ZobristConstants      = SamuraiZobristConstants(
      new samurai.Hash.ZobristConstants(start)
    )
    lazy val togyzkumalakTable: ZobristConstants = TogyzkumalakZobristConstants(
      new togyzkumalak.Hash.ZobristConstants(start)
    )
    lazy val goTable: ZobristConstants           = GoZobristConstants(new go.Hash.ZobristConstants(start))
    lazy val backgammonTable: ZobristConstants   = BackgammonZobristConstants(
      new backgammon.Hash.ZobristConstants(start)
    )
    lazy val abaloneTable: ZobristConstants      = AbaloneZobristConstants(
      new abalone.Hash.ZobristConstants(start)
    )
    lazy val dameoTable: ZobristConstants        = DameoZobristConstants(new dameo.Hash.ZobristConstants(start))
    lazy val entropyTable: ZobristConstants      = EntropyZobristConstants(
      new entropy.Hash.ZobristConstants(start)
    )

    def apply(lib: GameLogic): ZobristConstants = lib match {
      case GameLogic.Draughts()     => draughtsTable
      case GameLogic.Chess()        => chessTable
      case GameLogic.FairySF()      => fairysfTable
      case GameLogic.Samurai()      => samuraiTable
      case GameLogic.Togyzkumalak() => togyzkumalakTable
      case GameLogic.Go()           => goTable
      case GameLogic.Backgammon()   => backgammonTable
      case GameLogic.Abalone()      => abaloneTable
      case GameLogic.Dameo()        => dameoTable
      case GameLogic.Entropy()      => entropyTable
    }
  }

  // The following masks are compatible with the Polyglot
  // opening book format.
  private val polyglotTables = new Tables(0)
  private val randomTables   = new Tables(16)

  private def polyglotTable(lib: GameLogic): ZobristConstants = polyglotTables(lib)

  private def randomTable(lib: GameLogic): ZobristConstants = randomTables(lib)

  private def get(lib: GameLogic, situation: Situation, table: ZobristConstants): Long =
    (lib, situation, table) match {
      case (GameLogic.Draughts(), Situation.Draughts(situation), DraughtsZobristConstants(table))       =>
        draughts.Hash.get(situation, table)
      case (GameLogic.Chess(), Situation.Chess(situation), ChessZobristConstants(table))                =>
        chess.Hash.get(situation, table)
      case (GameLogic.FairySF(), Situation.FairySF(situation), FairySFZobristConstants(table))          =>
        fairysf.Hash.get(situation, table)
      case (GameLogic.Samurai(), Situation.Samurai(situation), SamuraiZobristConstants(table))          =>
        samurai.Hash.get(situation, table)
      case (
            GameLogic.Togyzkumalak(),
            Situation.Togyzkumalak(situation),
            TogyzkumalakZobristConstants(table)
          ) =>
        togyzkumalak.Hash.get(situation, table)
      case (GameLogic.Go(), Situation.Go(situation), GoZobristConstants(table))                         =>
        go.Hash.get(situation, table)
      case (GameLogic.Backgammon(), Situation.Backgammon(situation), BackgammonZobristConstants(table)) =>
        backgammon.Hash.get(situation, table)
      case (GameLogic.Abalone(), Situation.Abalone(situation), AbaloneZobristConstants(table))          =>
        abalone.Hash.get(situation, table)
      case (GameLogic.Dameo(), Situation.Dameo(situation), DameoZobristConstants(table))                =>
        dameo.Hash.get(situation, table)
      case (GameLogic.Entropy(), Situation.Entropy(situation), EntropyZobristConstants(table))          =>
        entropy.Hash.get(situation, table)
      case _                                                                                            => sys.error("Invalid lib, situation and table combination")
    }

  private val h = new Hash(size)

  def long(lib: GameLogic, situation: Situation) = Hash.get(lib, situation, Hash.polyglotTable(lib))

  def apply(lib: GameLogic, situation: Situation): PositionHash = h.apply(lib, situation)

  def debug(hashes: PositionHash) = hashes.map(_.toInt).sum.toString
}
