package strategygames

sealed abstract class Piece(val player: Player, val role: Role) {
  def is(c: Player)    = c == player
  def is(r: Role)      = r == role
  def isNot(c: Player) = c != player
  def isNot(r: Role)   = r != role

  def oneOf(rs: Set[Role]) = rs(role)

  def forsyth: Char

  override def toString = s"$player-$role".toLowerCase
}

object Piece {
  final case class Chess(p: chess.Piece)
      extends Piece(
        p.player,
        Role.ChessRole(p.role)
      ) {

    def forsyth: Char = p.forsyth
  }

  final case class Draughts(p: draughts.Piece)
      extends Piece(
        p.player,
        Role.DraughtsRole(p.role)
      ) {

    def forsyth: Char = p.forsyth
  }

  final case class FairySF(p: fairysf.Piece)
      extends Piece(
        p.player,
        Role.FairySFRole(p.role)
      ) {

    def forsyth: Char = p.forsyth
  }

  final case class Samurai(p: samurai.Piece)
      extends Piece(
        p.player,
        Role.SamuraiRole(p.role)
      ) {

    def forsyth: Char = p.forsyth
  }

  final case class Togyzkumalak(p: togyzkumalak.Piece)
      extends Piece(
        p.player,
        Role.TogyzkumalakRole(p.role)
      ) {

    def forsyth: Char = p.forsyth
  }

  final case class Go(p: go.Piece)
      extends Piece(
        p.player,
        Role.GoRole(p.role)
      ) {

    def forsyth: Char = p.forsyth
  }

  final case class Backgammon(p: backgammon.Piece)
      extends Piece(
        p.player,
        Role.BackgammonRole(p.role)
      ) {

    def forsyth: Char = p.forsyth
  }

  final case class Abalone(p: abalone.Piece)
      extends Piece(
        p.player,
        Role.AbaloneRole(p.role)
      ) {

    def forsyth: Char = p.forsyth
  }

  final case class Dameo(p: dameo.Piece)
      extends Piece(
        p.player,
        Role.DameoRole(p.role)
      ) {

    def forsyth: Char = p.forsyth
  }

  final case class Entropy(p: entropy.Piece)
      extends Piece(
        p.player,
        Role.EntropyRole(p.role)
      ) {

    def forsyth: Char = p.forsyth
  }

  final case class FiveInARow(p: fiveinarow.Piece)
      extends Piece(
        p.player,
        Role.FiveInARowRole(p.role)
      ) {

    def forsyth: Char = p.forsyth
  }

  final case class Yonkoma(p: yonkoma.Piece)
      extends Piece(
        p.player,
        Role.YonkomaRole(p.role)
      ) {

    def forsyth: Char = p.forsyth
  }

  def apply(lib: GameLogic, player: Player, role: Role): Piece = (lib, role) match {
    case (GameLogic.Draughts(), Role.DraughtsRole(role))         => Draughts(draughts.Piece(player, role))
    case (GameLogic.Chess(), Role.ChessRole(role))               => Chess(chess.Piece(player, role))
    case (GameLogic.FairySF(), Role.FairySFRole(role))           => FairySF(fairysf.Piece(player, role))
    case (GameLogic.Samurai(), Role.SamuraiRole(role))           => Samurai(samurai.Piece(player, role))
    case (GameLogic.Togyzkumalak(), Role.TogyzkumalakRole(role)) =>
      Togyzkumalak(togyzkumalak.Piece(player, role))
    case (GameLogic.Go(), Role.GoRole(role))                     => Go(go.Piece(player, role))
    case (GameLogic.Backgammon(), Role.BackgammonRole(role))     => Backgammon(backgammon.Piece(player, role))
    case (GameLogic.Abalone(), Role.AbaloneRole(role))           => Abalone(abalone.Piece(player, role))
    case (GameLogic.Dameo(), Role.DameoRole(role))               => Dameo(dameo.Piece(player, role))
    case (GameLogic.Entropy(), Role.EntropyRole(role))           => Entropy(entropy.Piece(player, role))
    case (GameLogic.FiveInARow(), Role.FiveInARowRole(role))     => FiveInARow(fiveinarow.Piece(player, role))
    case (GameLogic.Yonkoma(), Role.YonkomaRole(role))           => Yonkoma(yonkoma.Piece(player, role))
    case _                                                       => sys.error("Mismatched gamelogic types 2")
  }

  def fromChar(lib: GameLogic, gf: GameFamily, c: Char): Option[Piece] = lib match {
    case (GameLogic.Draughts())     => draughts.Piece.fromChar(c).map(Draughts.apply)
    case (GameLogic.Chess())        => chess.Piece.fromChar(c).map(Chess.apply)
    case (GameLogic.FairySF())      => fairysf.Piece.fromChar(gf, c).map(FairySF.apply)
    case (GameLogic.Samurai())      => sys.error("cannot get piece from Char for samurai anymore")
    case (GameLogic.Togyzkumalak()) => sys.error("cannot get piece from Char for togyzkumalak anymore")
    case (GameLogic.Go())           => sys.error("cannot get piece from Char for go anymore")
    case (GameLogic.Backgammon())   => sys.error("cannot get piece from Char for backgammon anymore")
    case (GameLogic.Abalone())      => sys.error("cannot get piece from Char for abalone anymore")
    case (GameLogic.Dameo())        => dameo.Piece.fromChar(c).map(Dameo.apply)
    case (GameLogic.Entropy())      => entropy.Piece.fromChar(c).map(Entropy.apply)
    case (GameLogic.FiveInARow())   => sys.error("a stone's owner depends on the position, not its char")
    case (GameLogic.Yonkoma())      => yonkoma.Piece.fromChar(c).map(Yonkoma.apply)
  }

  def chessPieceMap(pieceMap: PieceMap): chess.PieceMap = pieceMap.flatMap {
    case (Pos.Chess(pos), (Chess(piece), _)) => Some((pos, piece))
    case _                                   => None
  }

  def draughtsPieceMap(pieceMap: PieceMap): draughts.PieceMap = pieceMap.flatMap {
    case (Pos.Draughts(pos), (Draughts(piece), _)) => Some((pos, piece))
    case _                                         => None
  }

  def fairySFPieceMap(pieceMap: PieceMap): fairysf.PieceMap = pieceMap.flatMap {
    case (Pos.FairySF(pos), (FairySF(piece), _)) => Some((pos, piece))
    case _                                       => None
  }

  def samuraiPieceMap(pieceMap: PieceMap): samurai.PieceMap = pieceMap.flatMap {
    case (Pos.Samurai(pos), (Samurai(piece), count)) => Some((pos, (piece, count)))
    case _                                           => None
  }

  def togyzkumalakPieceMap(pieceMap: PieceMap): togyzkumalak.PieceMap = pieceMap.flatMap {
    case (Pos.Togyzkumalak(pos), (Togyzkumalak(piece), count)) => Some((pos, (piece, count)))
    case _                                                     => None
  }

  def goPieceMap(pieceMap: PieceMap): go.PieceMap = pieceMap.flatMap {
    case (Pos.Go(pos), (Go(piece), _)) =>
      Some((pos, piece))
    case _                             => None
  }

  def backgammonPieceMap(pieceMap: PieceMap): backgammon.PieceMap = pieceMap.flatMap {
    case (Pos.Backgammon(pos), (Backgammon(piece), count)) => Some((pos, (piece, count)))
    case _                                                 => None
  }

  def abalonePieceMap(pieceMap: PieceMap): abalone.PieceMap = pieceMap.flatMap {
    case (Pos.Abalone(pos), (Abalone(piece), _)) => Some((pos, piece))
    case _                                       => None
  }

  def dameoPieceMap(pieceMap: PieceMap): dameo.PieceMap = pieceMap.flatMap {
    case (Pos.Dameo(pos), (Dameo(piece), _)) => Some((pos, piece))
    case _                                   => None
  }

  def pieceMapForChess(pieces: strategygames.chess.PieceMap): PieceMap = pieces.flatMap { case (pos, piece) =>
    Some((Pos.Chess(pos), (Piece.Chess(piece), 1)))
  }
}
