package strategygames.entropy

import strategygames.{ GameFamily, P1, P2, Player }

sealed trait Role {
  val forsyth: Char
  val forsythUpper: Char
  lazy val pgn: Char              = forsyth
  lazy val name                   = toString
  lazy val groundName             = s"${forsyth}-piece"
  val binaryInt: Int
  val hashInt: Int
  val storable: Boolean
  lazy val valueOf: Option[Int]   = Option(1)
  lazy val gameFamily: GameFamily = GameFamily.Entropy()
  final def -(player: Player)     = Piece(player, this)
  final def p1                    = this - P1
  final def p2                    = this - P2
}

sealed trait PromotableRole extends Role

case object White extends Role {
  val forsyth      = 'w'
  val forsythUpper = 'W'
  val binaryInt    = 0
  val hashInt      = 0
  val storable     = true
}

case object Black extends Role {
  val forsyth      = 'k'
  val forsythUpper = 'K'
  val binaryInt    = 1
  val hashInt      = 1
  val storable     = true
}

case object Yellow extends Role {
  val forsyth      = 'y'
  val forsythUpper = 'Y'
  val binaryInt    = 2
  val hashInt      = 2
  val storable     = true
}

case object Green extends Role {
  val forsyth      = 'g'
  val forsythUpper = 'G'
  val binaryInt    = 3
  val hashInt      = 3
  val storable     = true
}

case object Red extends Role {
  val forsyth      = 'r'
  val forsythUpper = 'R'
  val binaryInt    = 4
  val hashInt      = 4
  val storable     = true
}

case object Blue extends Role {
  val forsyth      = 'b'
  val forsythUpper = 'B'
  val binaryInt    = 5
  val hashInt      = 5
  val storable     = true
}

case object Purple extends Role {
  val forsyth      = 'p'
  val forsythUpper = 'P'
  val binaryInt    = 6
  val hashInt      = 6
  val storable     = true
}

object Role {

  val all: List[Role] = List(White, Black, Yellow, Green, Red, Blue, Purple)

  def defaultRole: Role = White

  def allByGameFamily(gf: GameFamily): List[Role] =
    all.filter(r => r.gameFamily == gf)

  val allByForsyth: Map[Char, Role]                      = all map { r =>
    (r.forsyth, r)
  } toMap
  def allByForsyth(gf: GameFamily): Map[Char, Role]      = allByGameFamily(gf) map { r =>
    (r.forsyth, r)
  } toMap
  val allByPgn: Map[Char, Role]                          = all map { r =>
    (r.pgn, r)
  } toMap
  def allByPgn(gf: GameFamily): Map[Char, Role]          = allByGameFamily(gf) map { r =>
    (r.pgn, r)
  } toMap
  val allByName: Map[String, Role]                       = all map { r =>
    (r.name, r)
  } toMap
  def allByName(gf: GameFamily): Map[String, Role]       = allByGameFamily(gf) map { r =>
    (r.name, r)
  } toMap
  val allByGroundName: Map[String, Role]                 = all map { r =>
    (r.groundName, r)
  } toMap
  def allByGroundName(gf: GameFamily): Map[String, Role] = allByGameFamily(gf) map { r =>
    (r.groundName, r)
  } toMap
  val allByBinaryInt: Map[Int, Role]                     = all map { r =>
    (r.binaryInt, r)
  } toMap
  def allByBinaryInt(gf: GameFamily): Map[Int, Role]     = allByGameFamily(gf) map { r =>
    (r.binaryInt, r)
  } toMap
  val allByHashInt: Map[Int, Role]                       = all map { r =>
    (r.hashInt, r)
  } toMap

  def forsyth(c: Char): Option[Role] = allByForsyth get c

  def binaryInt(i: Int): Option[Role] = allByBinaryInt get i

  def hashInt(i: Int): Option[Role] = allByHashInt get i

  def storable: List[Role] = all.filter(_.storable)

  // only used in lila by insight module
  def pgnMoveToRole(gf: GameFamily, c: Char): Role =
    allByPgn(gf).get(c) match {
      case Some(r) => r
      case None    => sys.error(s"Could not find Role from pgnMove: $c (gf: $gf)")
    }

  // unused by lila
  def javaSymbolToRole(s: String): Role =
    allByPgn
      .get(
        s.headOption match {
          case Some(c) => c
          case None    => sys.error(s"Could not find Role from java symbol: $s")
        }
      )
      .get

  // unused by lila
  def javaSymbolToInt(s: String): Int =
    s.headOption match {
      case Some(c) if c.toInt >= 65 && c.toInt <= 90  => c.toInt - 64
      case Some(c) if c.toInt >= 97 && c.toInt <= 122 => c.toInt - 70
      case _                                          => sys.error(s"Could not get Int from java symbol: $s")
    }

  def valueOf(r: Role): Option[Int] = r.valueOf

  val roleR  = s"([${allByForsyth.keys.mkString("")}])"
  val roleRr = s"([${allByForsyth.keys.map(k => s"${k.toLower}${k.toUpper}").mkString("")}]?)"

}
