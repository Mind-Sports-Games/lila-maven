package strategygames

import strategygames.format.Uci

sealed abstract class Pass(
    val situationBefore: Situation,
    val after: Board,
    val autoEndTurn: Boolean,
    val metrics: MoveMetrics = MoveMetrics()
) extends Action(situationBefore) {
  def situationAfter: Situation

  def finalizeAfter: Board

  def player: Player = situationBefore.player

  def toUci: Uci.Pass

  override def toString: String

  // TODO: Yup, still not type safe. :D
  def toGo: go.Pass
  def toEntropy: entropy.Pass
}

object Pass {
  final case class Go(p: go.Pass)
      extends Pass(
        Situation.Go(p.situationBefore),
        Board.Go(p.after),
        p.autoEndTurn,
        p.metrics
      ) {

    def situationAfter: Situation = Situation.Go(p.situationAfter)
    def finalizeAfter: Board      = p.finalizeAfter

    def toUci: Uci.Pass = Uci.GoPass((p.toUci: go.format.Uci.Pass))

    val unwrap = p

    def toFairySF      = sys.error("Can't make a fairysf pass from a go pass")
    def toChess        = sys.error("Can't make a chess pass from a go pass")
    def toDraughts     = sys.error("Can't make a draughts pass from a go pass")
    def toSamurai      = sys.error("Can't make a samurai pass from a go pass")
    def toTogyzkumalak = sys.error("Can't make a togyzkumalak pass from a go pass")
    def toGo           = p
    def toBackgammon   = sys.error("Can't make a backgammon pass from a go pass")
    def toAbalone      = sys.error("Can't make an abalone pass from a go pass")
    def toDameo        = sys.error("Can't make a dameo pass from a go pass")
    def toEntropy      = sys.error("Can't make an entropy pass from a go pass")
  }

  def wrap(p: go.Pass): Pass = Pass.Go(p)

  final case class Entropy(p: entropy.Pass)
      extends Pass(
        Situation.Entropy(p.situationBefore),
        Board.Entropy(p.after),
        true,
        p.metrics
      ) {

    def situationAfter: Situation = Situation.Entropy(p.situationAfter)
    def finalizeAfter: Board      = p.finalizeAfter

    def toUci: Uci.Pass = Uci.EntropyPass((p.toUci: entropy.format.Uci.Pass))

    val unwrap = p

    def toChess        = sys.error("Can't make a chess pass from an entropy pass")
    def toDraughts     = sys.error("Can't make a draughts pass from an entropy pass")
    def toFairySF      = sys.error("Can't make a fairysf pass from an entropy pass")
    def toSamurai      = sys.error("Can't make a samurai pass from an entropy pass")
    def toTogyzkumalak = sys.error("Can't make a togyzkumalak pass from an entropy pass")
    def toGo           = sys.error("Can't make a go pass from an entropy pass")
    def toBackgammon   = sys.error("Can't make a backgammon pass from an entropy pass")
    def toAbalone      = sys.error("Can't make a abalone pass from an entropy pass")
    def toDameo        = sys.error("Can't make a dameo pass from an entropy pass")
    def toEntropy      = p

    override def toString = toUci.uci
  }

}
