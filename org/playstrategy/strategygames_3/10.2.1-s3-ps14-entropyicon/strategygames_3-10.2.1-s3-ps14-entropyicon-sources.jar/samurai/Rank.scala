package strategygames.samurai

case class Rank private (val index: Int) extends AnyVal with Ordered[Rank] {
  @inline def -(that: Rank): Int           = index - that.index
  @inline override def compare(that: Rank) = this - that

  def offset(delta: Int): Option[Rank] =
    if (-Rank.allSize < delta && delta < Rank.allSize) Rank(index + delta)
    else None

  @inline def char: Char = if (index < 9) (49 + index).toChar else 48.toChar // 0
  override def toString  = (index + 1).toString
}

object Rank {
  def apply(index: Int): Option[Rank] =
    if (0 <= index && index < allSize) Some(new Rank(index))
    else None

  @inline def of(pos: Pos): Rank = new Rank(pos.index / File.allSize)

  def fromChar(ch: Char): Option[Rank] = apply(if (ch.toInt == 48) 9 else ch.toInt - 49)

  val First  = new Rank(0)
  val Second = new Rank(1)

  // val all = List(First, Second, Third, Fourth, Fifth, Sixth, Seventh, Eighth, Ninth, Tenth)
  val all                     = List(First, Second)
  val allReversed: List[Rank] = all.reverse
  val allSize: Int            = all.size

}
