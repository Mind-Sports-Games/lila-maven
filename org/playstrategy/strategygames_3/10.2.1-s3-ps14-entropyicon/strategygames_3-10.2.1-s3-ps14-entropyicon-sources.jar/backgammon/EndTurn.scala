package strategygames.backgammon
import strategygames.MoveMetrics

import strategygames.backgammon.format.Uci

case class EndTurn(
    situationBefore: Situation,
    after: Board,
    metrics: MoveMetrics = MoveMetrics()
) extends Action(situationBefore, after, metrics) {

  def player = situationBefore.player

  def playerAfter = !player

  def situationAfter =
    Situation(finalizeAfter, playerAfter)

  def finalizeAfter: Board = after updateHistory { h =>
    h.copy(
      lastTurn = h.currentTurn :+ toUci,
      currentTurn = List(),
      forcedTurn = false,
      justUsedUndo = false,
      halfMoveClock = h.halfMoveClock + playerAfter.fold(1, 0)
    )
  }

  lazy val lazySituationAfter = situationAfter

  def withMetrics(m: MoveMetrics): EndTurn = copy(metrics = m)

  def toUci: Uci.EndTurn = Uci.EndTurn()

  override def toString = toUci.uci

}
