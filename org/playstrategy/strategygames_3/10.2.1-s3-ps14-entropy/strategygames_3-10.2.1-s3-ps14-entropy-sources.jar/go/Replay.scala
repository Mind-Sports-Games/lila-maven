package strategygames.go

import cats.data.Validated
import cats.data.Validated.valid
import cats.implicits._
import scalalib.extensions.*

import strategygames.Player
import strategygames.format.pgn.San
import strategygames.go.format.pgn.{ Parser, Reader }
import strategygames.go.format.{ FEN, Forsyth, Uci }
import strategygames.{
  Action => StratAction,
  ActionStrs,
  Drop => StratDrop,
  Pass => StratPass,
  SelectSquares => StratSelectSquares,
  Situation => StratSituation
}

case class Replay(setup: Game, actions: List[Action], state: Game) {

  lazy val chronoPlies = actions.reverse

  lazy val chronoActions: List[List[Action]] =
    chronoPlies
      .drop(1)
      .foldLeft(List(chronoPlies.take(1))) { case (turn, action) =>
        if (turn.head.head.player != action.player) {
          List(action) +: turn
        } else {
          (turn.head :+ action) +: turn.tail
        }
      }
      .reverse

  def addAction(action: Action) = action match {
    case d: Drop           =>
      copy(
        actions = d.applyVariantEffect :: actions,
        state = state.applyDrop(d)
      )
    case p: Pass           =>
      copy(
        actions = p :: actions,
        state = state.applyPass(p)
      )
    case ss: SelectSquares =>
      copy(
        actions = ss :: actions,
        state = state.applySelectSquares(ss)
      )
  }

}

object Replay {

  def apply(game: Game) = new Replay(game, Nil, game)

  def apply(
      actionStrs: ActionStrs,
      startPlayer: Player,
      activePlayer: Player,
      initialFen: Option[FEN],
      variant: strategygames.go.variant.Variant
  ): Validated[String, Reader.Result] = {
    val fen                            = initialFen.getOrElse(variant.initialFen)
    val (init, gameWithActions, error) =
      gameWithActionWhileValid(actionStrs, startPlayer, activePlayer, fen, variant)
    val game                           =
      gameWithActions.reverse.lastOption.map(_._1).getOrElse(init)

    error match {
      case None      =>
        Validated.valid(
          Reader.Result.Complete(
            new Replay(init, gameWithActions.reverse.map(_._2), game)
          )
        )
      case Some(msg) => Validated.invalid(msg)
    }
  }

  // TODO: because this is primarily used in a Validation context, we should be able to
  //       return something that's runtime safe as well.
  private def goAction(action: StratAction) = action match {
    case StratDrop.Go(d)           => d
    case StratPass.Go(p)           => p
    case StratSelectSquares.Go(ss) => ss
    case _                         => sys.error("Invalid go action")
  }

  def replayDrop(before: Situation, role: Role, dest: Pos, endTurn: Boolean): Drop =
    Drop(
      piece = Piece(before.player, role),
      pos = dest,
      situationBefore = before,
      autoEndTurn = endTurn
    )

  def replayPass(before: Situation, endTurn: Boolean): Pass =
    Pass(
      situationBefore = before,
      after = before.board.variant.boardAfterPass(before),
      autoEndTurn = endTurn
    )

  def replaySelectSquares(before: Situation, squares: List[Pos], endTurn: Boolean): SelectSquares =
    SelectSquares(
      squares = squares,
      situationBefore = before,
      autoEndTurn = endTurn
    )

  private def replayAction(before: Situation, uci: Uci): Action = uci match {
    case Uci.Drop(role, dest)      => replayDrop(before, role, dest, endTurn = true)
    case Uci.Pass()                => replayPass(before, endTurn = true)
    case Uci.SelectSquares(points) => replaySelectSquares(before, points, endTurn = true)
  }

  // NOTE: nothing here adjudicates the record against the rules — the record is what was played. Only
  // an action string this file cannot read at all stops a replay.
  private def actionOf(
      before: Situation,
      actionStr: String,
      endTurn: Boolean
  ): Validated[String, Action] =
    actionStr match {
      case Uci.Drop.dropR(role, dest)           =>
        (Role.allByForsyth(before.board.variant.gameFamily).get(role(0)), Pos.fromKey(dest)) match {
          // NOTE: the vacancy test is a precondition rather than a rule. `Variant.boardAfter` reaches
          // `Chain.capturedBy`, which asserts it through `Chain.requireVacant`, and that assertion is
          // the one thing on this path that raises. Testing it here is what keeps a record naming an
          // occupied point to a truncated game and a reported reason. Nothing else is asked: the ko
          // point, superko and a finished game are rules, and rules have changed under stored records.
          case (Some(role), Some(dest)) if !before.board.pieces.contains(dest) =>
            valid(replayDrop(before, role, dest, endTurn))
          case (Some(_), Some(_))                                              =>
            Validated.invalid(s"Unplayable drop ${actionStr} for replay: a stone already stands there")
          case _                                                               =>
            Validated.invalid(s"Invalid drop for replay: ${actionStr}")
        }
      case Uci.Pass.passR()                     => valid(replayPass(before, endTurn))
      // NOTE: a key naming no point on this board size is dropped here, where the drop branch above
      // refuses the whole action on the same input. Stored games carry stray keys and still load.
      // TODO(playstrategy): make this a `traverse` once those records have been swept.
      case Uci.SelectSquares.selectSquaresR(ss) =>
        valid(replaySelectSquares(before, ss.split(",").toList.flatMap(Pos.fromKey(_)), endTurn))
      case _                                    =>
        Validated.invalid(s"Invalid actionStr for replay: ${actionStr}")
    }

  // NOTE: `Drop.after` and `SelectSquares.after` are `lazy val`s over the variant's `boardAfter*`,
  // which compute a board rather than judging one, so the board is built from here rather than at
  // construction. The vacancy test in `actionOf` has already refused the one input that would raise.
  private def applied(state: Game, action: Action): Game = action match {
    case d: Drop           => state.applyDrop(d)
    case p: Pass           => state.applyPass(p)
    case ss: SelectSquares => state.applySelectSquares(ss)
  }

  def actionStrsWithEndTurn(actionStrs: ActionStrs): Seq[(String, Boolean)] =
    actionStrs.zipWithIndex.map { case (a, i) =>
      a.zipWithIndex.map { case (a1, i1) => (a1, i1 == a.size - 1 && i != actionStrs.size - 1) }
    }.flatten

  private def combineActionStrsWithEndTurn(
      actionStrs: ActionStrs,
      startPlayer: Player,
      activePlayer: Player
  ): Seq[(String, Boolean)] =
    actionStrsWithEndTurn(
      if (Player.fromTurnCount(actionStrs.size + startPlayer.fold(0, 1)) == activePlayer)
        actionStrs :+ Vector()
      else actionStrs
    )

  // NOTE: this replays while the record stays readable and then stops, handing back the plies it built
  // and the reason it stopped — the shape `chess.Replay.mk` and `draughts.Replay.mk` use. Nothing here
  // raises: `strategygames.Replay.gameWithUciWhileValid` returns the triple to lila's `StepBuilder`,
  // which logs the reason and renders the plies, so an unreadable action costs a game its tail rather
  // than costing it the whole load.
  private def gameWithActionWhileValid(
      actionStrs: ActionStrs,
      startPlayer: Player,
      activePlayer: Player,
      initialFen: FEN,
      variant: strategygames.go.variant.Variant
  ): (Game, List[(Game, Action)], Option[String]) = {

    val init = makeGame(variant, initialFen.some)

    def mk(state: Game, rest: List[(String, Boolean)]): (List[(Game, Action)], Option[String]) =
      rest match {
        case (actionStr, endTurn) :: tail =>
          actionOf(state.situation, actionStr, endTurn).fold(
            error => (Nil, error.some),
            action => {
              val next = applied(state, action)
              mk(next, tail) match {
                case (plies, message) => ((next, action) :: plies, message)
              }
            }
          )
        case Nil                          => (Nil, None)
      }

    mk(init, combineActionStrsWithEndTurn(actionStrs, startPlayer, activePlayer).toList) match {
      case (gameWithActions, error) => (init, gameWithActions, error)
    }
  }

  def gameWithUciWhileValid(
      actionStrs: ActionStrs,
      startPlayer: Player,
      activePlayer: Player,
      initialFen: FEN,
      variant: strategygames.go.variant.Variant
  ): (Game, List[(Game, Uci.WithSan)], Option[String]) = {
    val (game, gameWithActions, error) = gameWithActionWhileValid(
      actionStrs,
      startPlayer,
      activePlayer,
      initialFen,
      variant
    )
    (
      game,
      gameWithActions.map { v =>
        {
          val (state, action) = v
          (state, Uci.WithSan(Uci(action.toUci.uci).get, "NOSAN"))
        }
      },
      error
    )
  }

  private def recursiveSituations(sit: Situation, sans: List[San]): Validated[String, List[Situation]] =
    sans match {
      case Nil         => valid(Nil)
      case san :: rest =>
        san(StratSituation.wrap(sit)).map(goAction) andThen { action =>
          val after = Situation(action.finalizeAfter, !sit.player)
          recursiveSituations(after, rest) map { after :: _ }
        }
    }

  private def recursiveSituationsFromUci(
      sit: Situation,
      ucis: List[Uci]
  ): Validated[String, List[Situation]] =
    ucis match {
      case Nil         => valid(Nil)
      case uci :: rest =>
        val after = replayAction(sit, uci).situationAfter
        recursiveSituationsFromUci(after, rest) map { after :: _ }
    }

  private def recursiveReplayFromUci(replay: Replay, ucis: List[Uci]): Validated[String, Replay] =
    ucis match {
      case Nil         => valid(replay)
      case uci :: rest =>
        recursiveReplayFromUci(replay.addAction(replayAction(replay.state.situation, uci)), rest)
    }

  private def initialFenToSituation(
      initialFen: Option[FEN],
      variant: strategygames.go.variant.Variant
  ): Situation = {
    initialFen.flatMap(Forsyth.<<@(variant, _)) | Situation(variant)
  } withVariant variant

  def boards(
      actionStrs: ActionStrs,
      initialFen: Option[FEN],
      variant: strategygames.go.variant.Variant
  ): Validated[String, List[Board]] = situations(actionStrs, initialFen, variant) map (_ map (_.board))

  // NOTE: go actions are read as `Uci` rather than through `Parser.sans`, which is a stub that
  // refuses every go action string.
  def situations(
      actionStrs: ActionStrs,
      initialFen: Option[FEN],
      variant: strategygames.go.variant.Variant
  ): Validated[String, List[Situation]] =
    situationsFromUci(actionStrs.flatten.toList.flatMap(Uci.apply), initialFen, variant)

  def boardsFromUci(
      ucis: List[Uci],
      initialFen: Option[FEN],
      variant: strategygames.go.variant.Variant
  ): Validated[String, List[Board]] = situationsFromUci(ucis, initialFen, variant) map (_ map (_.board))

  def situationsFromUci(
      ucis: List[Uci],
      initialFen: Option[FEN],
      variant: strategygames.go.variant.Variant
  ): Validated[String, List[Situation]] = {
    val sit = initialFenToSituation(initialFen, variant)
    recursiveSituationsFromUci(sit, ucis) map { sit :: _ }
  }

  def gameFromUciStrings(
      uciStrings: ActionStrs,
      activePlayer: Player,
      initialFen: Option[FEN],
      variant: strategygames.go.variant.Variant
  ): Validated[String, Game] = {
    val fen                            = initialFen.getOrElse(variant.initialFen)
    val (init, gameWithActions, error) =
      gameWithActionWhileValid(uciStrings, fen.player.getOrElse(Player.P1), activePlayer, fen, variant)

    error match {
      case None      => Validated.valid(gameWithActions.lastOption.map(_._1).getOrElse(init))
      case Some(msg) => Validated.invalid(msg)
    }
  }

  def apply(
      ucis: List[Uci],
      initialFen: Option[FEN],
      variant: strategygames.go.variant.Variant
  ): Validated[String, Replay] =
    recursiveReplayFromUci(Replay(makeGame(variant, initialFen)), ucis)

  private def makeGame(variant: strategygames.go.variant.Variant, initialFen: Option[FEN]): Game = {
    val g = Game(variant.some, initialFen)
    g.copy(startedAtPly = g.plies, startedAtTurn = g.turnCount)
  }

  // NOTE: go accepts a nine field fen as well as a ten field one, so both sides of the comparison are
  // read and re-exported first. That settles them on the ten field form and on this file's spelling
  // of every field. The full move number is then dropped, because the caller is asking which ply
  // reaches a position rather than what that ply is numbered.
  def plyAtFen(
      actionStrs: ActionStrs,
      initialFen: Option[FEN],
      variant: strategygames.go.variant.Variant,
      atFen: FEN
  ): Validated[String, Int] =
    normalised(variant, atFen).toValid(s"Invalid FEN $atFen") andThen { target =>
      situations(actionStrs, initialFen, variant) andThen { sits =>
        sits.iterator.zipWithIndex
          .collectFirst { case (sit, ply) if normalisedOf(sit) == target => ply }
          .toValid(s"Can't find $target, reached ply ${sits.size - 1}")
      }
    }

  private def normalised(variant: strategygames.go.variant.Variant, fen: FEN): Option[String] =
    Forsyth.<<@(variant, fen).map(normalisedOf)

  private def normalisedOf(situation: Situation): String =
    (Forsyth >> situation).value.split(' ').init.mkString(" ")
}
