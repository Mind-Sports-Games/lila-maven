package strategygames

//------------------------------------------------------------------------------
// At the moment these are the main fields that I see exposed to lila.
//
// I am certain there are more, but I think it's best to do these at the same
// time as fixing up the usage of these within lila.
//------------------------------------------------------------------------------

sealed abstract class Pos {
  val key: String

  def piotr: Char

  def piotrStr = piotr.toString

  def toInt: Int

  def gameLogic: GameLogic

  override def toString = key

  def all: List[Pos]
}

object Pos {
  final case class Chess(p: chess.Pos) extends Pos {
    val key: String = p.key

    def piotr: Char = p.piotr

    lazy val toInt: Int = (p.file.index << 3) + p.rank.index

    def gameLogic: GameLogic = GameLogic.Chess()

    lazy val all: List[Pos] = chess.Pos.all.map(Chess.apply)
  }

  final case class Draughts(p: draughts.Pos) extends Pos {
    val key: String = p.key

    def piotr: Char = p.piotr

    // TODO: not sure this is appropriate, but I don't see why not?
    lazy val toInt: Int = p.fieldNumber

    def gameLogic: GameLogic = GameLogic.Draughts()

    // TODO: this only handl 8x8 boards. we should include 10x10 as well.
    //       Not sure if we need a separate type, probably?
    lazy val all: List[Pos] = draughts.Pos64.all.map(Draughts.apply)
  }

  final case class FairySF(p: fairysf.Pos) extends Pos {
    val key: String = p.key

    def piotr: Char = p.piotr

    lazy val toInt: Int =
      (p.file.index << 3) + p.rank.index // todo where is this used? Should be 4 for fairy boards?

    def gameLogic: GameLogic = GameLogic.FairySF()

    lazy val all: List[Pos] = chess.Pos.all.map(Chess.apply)
  }

  final case class Samurai(p: samurai.Pos) extends Pos {
    val key: String = p.key

    def piotr: Char = p.piotr

    lazy val toInt: Int = (p.file.index << 3) + p.rank.index

    def gameLogic: GameLogic = GameLogic.Samurai()

    lazy val all: List[Pos] = samurai.Pos.all.map(Samurai.apply)
  }

  final case class Togyzkumalak(p: togyzkumalak.Pos) extends Pos {
    val key: String = p.key

    def piotr: Char = p.piotr

    lazy val toInt: Int = (p.file.index << 3) + p.rank.index

    def gameLogic: GameLogic = GameLogic.Togyzkumalak()

    lazy val all: List[Pos] = togyzkumalak.Pos.all.map(Togyzkumalak.apply)
  }

  final case class Go(p: go.Pos) extends Pos {
    val key: String = p.key

    def piotr: Char = p.piotr

    lazy val toInt: Int = (p.file.index << 5) + p.rank.index // todo where is this used?

    def gameLogic: GameLogic = GameLogic.Go()

    lazy val all: List[Pos] = go.Pos.all.map(Go.apply)
  }

  final case class Backgammon(p: backgammon.Pos) extends Pos {
    val key: String = p.key

    def piotr: Char = p.piotr

    lazy val toInt: Int = (p.file.index << 3) + p.rank.index

    def gameLogic: GameLogic = GameLogic.Backgammon()

    lazy val all: List[Pos] = backgammon.Pos.all.map(Backgammon.apply)
  }

  final case class Abalone(p: abalone.Pos) extends Pos {
    override val key: String = p.key

    override def piotr: Char = p.piotr

    override lazy val toInt: Int = (p.x << 4) + p.y

    override def gameLogic: GameLogic = GameLogic.Abalone()
    override lazy val all: List[Pos]  = abalone.Pos.all.map(Abalone.apply)
  }

  final case class Dameo(p: dameo.Pos) extends Pos {
    val key: String = p.key

    def piotr: Char = p.piotr

    lazy val toInt: Int = (p.file.index << 4) + p.rank.index

    def gameLogic: GameLogic = GameLogic.Dameo()

    lazy val all: List[Pos] = dameo.Pos.all.map(Dameo.apply)
  }

  final case class Entropy(p: entropy.Pos) extends Pos {
    val key: String = p.key

    def piotr: Char = p.piotr

    lazy val toInt: Int = (p.file.index << 4) + p.rank.index

    def gameLogic: GameLogic = GameLogic.Entropy()

    lazy val all: List[Pos] = entropy.Pos.all.map(Entropy.apply)
  }

  // need to equivalate this method for draughts probably
  // think we need to figure out a way to map into Draughts with a board size at this point
  def fromKey(lib: GameLogic, key: String): Option[Pos] = lib match {
    case GameLogic.Draughts()     => sys.error("Not implemented yet for draughts")
    case GameLogic.Chess()        => chess.Pos.fromKey(key).map(Chess.apply)
    case GameLogic.FairySF()      => fairysf.Pos.fromKey(key).map(FairySF.apply)
    case GameLogic.Samurai()      => samurai.Pos.fromKey(key).map(Samurai.apply)
    case GameLogic.Togyzkumalak() => togyzkumalak.Pos.fromKey(key).map(Togyzkumalak.apply)
    case GameLogic.Go()           => go.Pos.fromKey(key).map(Go.apply)
    case GameLogic.Backgammon()   => backgammon.Pos.fromKey(key).map(Backgammon.apply)
    case GameLogic.Abalone()      => abalone.Pos.fromKey(key).map(Abalone.apply)
    case GameLogic.Dameo()        => dameo.Pos.fromKey(key).map(Dameo.apply)
    case GameLogic.Entropy()      => entropy.Pos.fromKey(key).map(Entropy.apply)
  }

  // def at(lib: GameLogic, x: Int, y: Int): Option[Pos] = lib match {
  //  case GameLogic.Draughts() => draughts.Pos.at(x, y).map(Draughts)
  //  case GameLogic.Chess() => chess.Pos.at(x, y).map(Chess)
  // }

}
